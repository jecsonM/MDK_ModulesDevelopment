﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication
{
    internal class Program
    {
        //функции к заданию 1
        static string LongestDigitSequanceInRow(string s, out int indRes, out int nRes)
        {
            indRes = 0;
            nRes = 0;
            int n = 0;
            if (s == "") return "";
            for (int i = 0; i < s.Length; i++)
            {
                if ((s[i] >= 48) && (s[i] <= 57)) //Проверяет, что символ s[i] это цифра (по коду символа)
                {
                    n++;
                    if (nRes < n)
                    {
                        nRes = n;
                        indRes = i; //сейчас это индекс последней цифры в последовательности
                    }
                    
                }
                else
                    n = 0;
            }
            indRes -= nRes - 1; //получение индекса первой цифры последовательности
            return s.Substring(indRes, nRes); //Возвращает самую длинную последовательность цифр
        }

        static string LongestDigitSequanceInRow(string s) //Функция без возвращаемых переменных indRes nRes
        {
            int indRes, nRes = 0;
            return LongestDigitSequanceInRow(s, out  indRes, out nRes); //Вызов функции с такой же реализацией
        }

        static string removeLongestDigitsSequence(string s)
        {
            int indRes, nRes, nResFirst=0;
            LongestDigitSequanceInRow(s, out indRes, out nResFirst);
            nRes = nResFirst;
            do
            {
               s = s.Substring(0, indRes) + s.Substring(indRes + nRes); //соединяю две подстроки без подстроки, (indRes, nRes)
               LongestDigitSequanceInRow(s, out indRes, out nRes);
            } while ((nRes == nResFirst) && (nRes != 0)); //удаление последовательно всех последовательностей цифр
            return s;
        }
        //конец функций к заданию 1

        //функции к заданию 2

        //конец функций к заданию 2

        static void Main(string[] args)
        {
            //Задание 1

            //Console.WriteLine("Введите строку s");
            //Console.WriteLine("В этой строке мы найдём самую длинную последовательность подряд идущих цифр и удалим её.");

            //Console.Write("Введите s:");

            //string s = Console.ReadLine();

            //Console.WriteLine($"Первая самая длинная последовательность цифр в строке: {LongestDigitSequanceInRow(s)}");
            //Console.WriteLine($"Строка после удаления всех последовательностей самой большой длины: {removeLongestDigitsSequence(s)}");
            //Console.ReadKey();

            //Задание2

            List<int[]> massives = new int[,2];

            Console.ReadKey();
        }
    }
}
